import struct
import lzma
import zlib
from PIL import Image
MAGIC = b"CCV2"
def decode_file(image_file):
    img = Image.open(image_file).convert("RGBA")
    # Reconstruct the original byte stream from RGBA pixels
    raw = bytearray()
    for r, g, b, a in img.getdata():
        raw.extend((r, g, b, a))
    pos = 0
    magic = bytes(raw[pos:pos + 4])
    pos += 4
    if magic != MAGIC:
        raise ValueError("Not a ColorCode V2 file")
    if pos + 2 > len(raw):
        raise ValueError("Corrupt header")
    filename_len = struct.unpack(
        ">H",
        raw[pos:pos + 2]
    )[0]
    pos += 2
    if pos + filename_len > len(raw):
        raise ValueError("Corrupt filename")
    filename = bytes(
        raw[pos:pos + filename_len]
    ).decode("utf-8")
    pos += filename_len
    if pos + 8 > len(raw):
        raise ValueError("Corrupt header")
    original_size = struct.unpack(
        ">Q",
        raw[pos:pos + 8]
    )[0]
    pos += 8
    if pos + 4 > len(raw):
        raise ValueError("Corrupt header")
    stored_crc = struct.unpack(
        ">I",
        raw[pos:pos + 4]
    )[0]
    pos += 4
    compressed_data = bytes(raw[pos:])
    decompressor = lzma.LZMADecompressor()
    try:
        data = decompressor.decompress(compressed_data)
    except lzma.LZMAError as e:
        raise ValueError(
            f"LZMA decompression failed: {e}"
        )
    if not decompressor.eof:
        raise ValueError(
            "LZMA stream did not reach its end-of-stream marker"
        )
    if len(data) != original_size:
        raise ValueError(
            f"Size mismatch ({len(data)} != {original_size})"
        )
    actual_crc = zlib.crc32(data)
    if actual_crc != stored_crc:
        raise ValueError(
            f"CRC mismatch ({stored_crc} != {actual_crc})"
        )
    with open(filename, "wb") as f:
        f.write(data)
    print("Recovered:", filename)
    print("Size:", original_size)
    print("CRC:", f"{actual_crc:08X}")
    print("LZMA stream:", "OK")
if __name__ == "__main__":
    decode_file("colorcode.png")