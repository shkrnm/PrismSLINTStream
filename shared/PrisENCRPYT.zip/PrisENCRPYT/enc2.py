import os
import math
import lzma
import zlib
import struct
from PIL import Image
MAGIC = b"CCV2"
def encode_file(input_file, output_png):
    with open(input_file, "rb") as f:
        payload = f.read()
    filename = os.path.basename(input_file).encode("utf-8")
    compressed = lzma.compress(payload, preset=9)
    crc = zlib.crc32(payload)
    header = bytearray()
    header += MAGIC
    header += struct.pack(">H", len(filename))
    header += filename
    header += struct.pack(">Q", len(payload))
    header += struct.pack(">I", crc)
    data = header + compressed
    while len(data) % 4:
        data += b"\x00"
    pixels = len(data) // 4
    side = math.ceil(math.sqrt(pixels))
    total_bytes_needed = side * side * 4
    data += b"\x00" * (total_bytes_needed - len(data))
    img = Image.new("RGBA", (side, side))
    pixel_data = []
    for i in range(0, len(data), 4):
        pixel_data.append((
            data[i],
            data[i + 1],
            data[i + 2],
            data[i + 3]
        ))
    img.putdata(pixel_data)
    img.save(
        output_png,
        optimize=True,
        compress_level=9
    )
    print("Done!")
    print("Original size:", len(payload))
    print("Compressed size:", len(compressed))
    print("Image size:", side, "x", side)
if __name__ == "__main__":
    encode_file("input.bin", "colorcode.png")